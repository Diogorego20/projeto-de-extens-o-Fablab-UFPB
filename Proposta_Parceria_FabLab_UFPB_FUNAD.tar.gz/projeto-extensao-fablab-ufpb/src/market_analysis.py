#!/usr/bin/env python3
"""
Análise de Mercado de Brinquedos Pedagógicos para Autismo no Brasil
==================================================================

Este módulo contém os cálculos e análises estatísticas utilizados na
proposta de parceria entre FabLab UFPB e FUNAD.

Autor: Equipe FabLab UFPB
Data: Agosto 2024
Versão: 1.0.0
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from typing import Dict, List, Tuple
from dataclasses import dataclass
from pathlib import Path
import logging

# Configuração de logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Configuração de estilo para gráficos
plt.style.use('seaborn-v0_8')
sns.set_palette("husl")

@dataclass
class MarketData:
    """Classe para armazenar dados de mercado."""
    year: int
    revenue_billions: float
    growth_rate: float
    source: str

@dataclass
class AutismData:
    """Classe para armazenar dados sobre autismo."""
    total_population: int
    autism_population: int
    children_0_14: int
    children_5_9: int
    prevalence_rate: float
    source: str

class MarketAnalyzer:
    """
    Classe principal para análise de mercado de brinquedos pedagógicos.
    
    Esta classe encapsula todos os cálculos e análises estatísticas
    utilizados na proposta de parceria.
    """
    
    def __init__(self):
        """Inicializa o analisador com dados base."""
        self.market_data = self._load_market_data()
        self.autism_data = self._load_autism_data()
        self.output_dir = Path("../assets/graphics")
        self.output_dir.mkdir(parents=True, exist_ok=True)
        
    def _load_market_data(self) -> List[MarketData]:
        """
        Carrega dados históricos do mercado de brinquedos.
        
        Returns:
            List[MarketData]: Lista com dados anuais do mercado
        """
        return [
            MarketData(2020, 7.5, 0.0, "Abrinq - Relatório 2020"),
            MarketData(2021, 8.2, 9.3, "Abrinq - Relatório 2021"),
            MarketData(2022, 8.9, 8.5, "Abrinq - Relatório 2022"),
            MarketData(2023, 9.4, 5.6, "Abrinq - Relatório 2023"),
            MarketData(2024, 10.2, 8.5, "Abrinq - Relatório 2024")
        ]
    
    def _load_autism_data(self) -> AutismData:
        """
        Carrega dados sobre autismo no Brasil.
        
        Returns:
            AutismData: Dados demográficos sobre autismo
        """
        return AutismData(
            total_population=214_000_000,
            autism_population=2_400_000,
            children_0_14=1_100_000,
            children_5_9=350_000,
            prevalence_rate=0.026,  # 2.6% na faixa 5-9 anos
            source="IBGE - Censo Demográfico 2022"
        )
    
    def calculate_market_growth(self) -> Dict[str, float]:
        """
        Calcula métricas de crescimento do mercado.
        
        Returns:
            Dict[str, float]: Métricas de crescimento calculadas
        """
        revenues = [data.revenue_billions for data in self.market_data]
        
        # Crescimento total no período
        total_growth = ((revenues[-1] / revenues[0]) - 1) * 100
        
        # Crescimento médio anual
        years = len(revenues) - 1
        cagr = (((revenues[-1] / revenues[0]) ** (1/years)) - 1) * 100
        
        # Crescimento absoluto
        absolute_growth = revenues[-1] - revenues[0]
        
        logger.info(f"Crescimento total calculado: {total_growth:.1f}%")
        logger.info(f"CAGR calculado: {cagr:.1f}%")
        
        return {
            "total_growth_percent": total_growth,
            "cagr_percent": cagr,
            "absolute_growth_billions": absolute_growth,
            "current_revenue": revenues[-1]
        }
    
    def calculate_autism_demographics(self) -> Dict[str, float]:
        """
        Calcula estatísticas demográficas sobre autismo.
        
        Returns:
            Dict[str, float]: Estatísticas demográficas calculadas
        """
        data = self.autism_data
        
        # Percentual da população com autismo
        autism_percentage = (data.autism_population / data.total_population) * 100
        
        # Percentual de crianças na população autista
        children_percentage = (data.children_0_14 / data.autism_population) * 100
        
        # Concentração na faixa 5-9 anos
        concentration_5_9 = (data.children_5_9 / data.children_0_14) * 100
        
        logger.info(f"Percentual da população com autismo: {autism_percentage:.2f}%")
        logger.info(f"Percentual de crianças: {children_percentage:.1f}%")
        
        return {
            "autism_population_percent": autism_percentage,
            "children_percent": children_percentage,
            "concentration_5_9_percent": concentration_5_9,
            "target_population": data.children_5_9
        }
    
    def calculate_market_potential(self, 
                                 engagement_rate: float = 0.70,
                                 annual_spending: float = 500.0) -> Dict[str, float]:
        """
        Calcula o potencial de mercado para brinquedos pedagógicos.
        
        Args:
            engagement_rate (float): Taxa de engajamento das famílias (padrão: 70%)
            annual_spending (float): Gasto anual médio por família (padrão: R$ 500)
            
        Returns:
            Dict[str, float]: Métricas de potencial de mercado
        """
        # Número de famílias engajadas
        engaged_families = int(self.autism_data.children_0_14 * engagement_rate)
        
        # Mercado potencial total
        total_market_potential = engaged_families * annual_spending
        
        # Mercado potencial em milhões
        market_potential_millions = total_market_potential / 1_000_000
        
        # Percentual do mercado total de brinquedos
        current_market = self.calculate_market_growth()["current_revenue"] * 1_000_000_000
        market_share_percent = (total_market_potential / current_market) * 100
        
        logger.info(f"Famílias engajadas: {engaged_families:,}")
        logger.info(f"Potencial de mercado: R$ {market_potential_millions:.0f} milhões")
        
        return {
            "engaged_families": engaged_families,
            "market_potential_millions": market_potential_millions,
            "market_share_percent": market_share_percent,
            "annual_spending_per_family": annual_spending
        }
    
    def calculate_regional_distribution(self) -> Dict[str, int]:
        """
        Calcula a distribuição regional da população autista.
        
        Returns:
            Dict[str, int]: População autista por região
        """
        # Distribuição baseada em dados demográficos do IBGE
        regional_percentages = {
            "Sudeste": 0.42,
            "Nordeste": 0.28,
            "Sul": 0.14,
            "Norte": 0.09,
            "Centro-Oeste": 0.07
        }
        
        total_autism = self.autism_data.autism_population
        
        regional_distribution = {
            region: int(total_autism * percentage)
            for region, percentage in regional_percentages.items()
        }
        
        logger.info("Distribuição regional calculada")
        return regional_distribution
    
    def generate_market_growth_chart(self) -> str:
        """
        Gera gráfico de crescimento do mercado.
        
        Returns:
            str: Caminho do arquivo gerado
        """
        fig, ax = plt.subplots(figsize=(12, 8))
        
        years = [data.year for data in self.market_data]
        revenues = [data.revenue_billions for data in self.market_data]
        
        # Gráfico de barras
        bars = ax.bar(years, revenues, color=['#4CAF50', '#66BB6A', '#81C784', '#A5D6A7', '#2E7D32'])
        
        # Adicionar valores nas barras
        for bar, revenue in zip(bars, revenues):
            height = bar.get_height()
            ax.text(bar.get_x() + bar.get_width()/2., height + 0.1,
                   f'R$ {revenue:.1f}B', ha='center', va='bottom', fontweight='bold')
        
        # Linha de tendência
        z = np.polyfit(years, revenues, 1)
        p = np.poly1d(z)
        ax.plot(years, p(years), "r--", alpha=0.8, linewidth=2, label='Tendência')
        
        # Destacar crescimento
        growth = self.calculate_market_growth()
        ax.text(0.02, 0.98, f'Crescimento de {growth["total_growth_percent"]:.0f}% em 4 anos',
                transform=ax.transAxes, fontsize=12, fontweight='bold',
                bbox=dict(boxstyle="round,pad=0.3", facecolor="yellow", alpha=0.7),
                verticalalignment='top')
        
        ax.set_title('Crescimento do Mercado de Brinquedos no Brasil\n(2020-2024)', 
                    fontsize=16, fontweight='bold', pad=20)
        ax.set_xlabel('Ano', fontsize=12)
        ax.set_ylabel('Faturamento (Bilhões R$)', fontsize=12)
        ax.grid(True, alpha=0.3)
        ax.legend()
        
        # Salvar gráfico
        output_path = self.output_dir / "crescimento_mercado_profissional.png"
        plt.tight_layout()
        plt.savefig(output_path, dpi=300, bbox_inches='tight')
        plt.close()
        
        logger.info(f"Gráfico de crescimento salvo em: {output_path}")
        return str(output_path)
    
    def generate_autism_demographics_chart(self) -> str:
        """
        Gera gráfico de demografia do autismo.
        
        Returns:
            str: Caminho do arquivo gerado
        """
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 8))
        
        # Gráfico 1: Distribuição por faixa etária
        age_groups = ['0-4 anos', '5-9 anos', '10-14 anos', '15-19 anos', '20+ anos']
        prevalence = [2.1, 2.6, 1.9, 1.2, 0.8]  # Dados do IBGE
        
        bars1 = ax1.bar(age_groups, prevalence, color=['#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FFEAA7'])
        
        # Destacar faixa principal
        bars1[1].set_color('#2E7D32')
        bars1[1].set_edgecolor('black')
        bars1[1].set_linewidth(2)
        
        # Adicionar valores
        for bar, prev in zip(bars1, prevalence):
            height = bar.get_height()
            ax1.text(bar.get_x() + bar.get_width()/2., height + 0.05,
                    f'{prev}%', ha='center', va='bottom', fontweight='bold')
        
        # Destacar maior prevalência
        ax1.text(1, 2.8, 'Maior prevalência\n(5-9 anos)', ha='center', va='bottom',
                bbox=dict(boxstyle="round,pad=0.3", facecolor="lightgreen", alpha=0.8),
                fontweight='bold')
        
        ax1.set_title('Prevalência de Autismo por Faixa Etária no Brasil\n(Censo 2022)', 
                     fontsize=14, fontweight='bold')
        ax1.set_ylabel('Prevalência (%)', fontsize=12)
        ax1.grid(True, alpha=0.3)
        
        # Gráfico 2: População absoluta
        demographics = self.calculate_autism_demographics()
        
        categories = ['População\nTotal', 'Crianças\n0-14 anos', 'Faixa Principal\n5-9 anos']
        values = [2.4, 1.1, 0.35]  # Em milhões
        colors = ['#2196F3', '#4CAF50', '#FF9800']
        
        bars2 = ax2.bar(categories, values, color=colors)
        
        # Adicionar valores
        for bar, value in zip(bars2, values):
            height = bar.get_height()
            ax2.text(bar.get_x() + bar.get_width()/2., height + 0.05,
                    f'{value}M', ha='center', va='bottom', fontweight='bold', fontsize=12)
        
        ax2.set_title('População com Autismo no Brasil\n(Números Absolutos)', 
                     fontsize=14, fontweight='bold')
        ax2.set_ylabel('População (Milhões)', fontsize=12)
        ax2.grid(True, alpha=0.3)
        
        # Salvar gráfico
        output_path = self.output_dir / "demografia_autismo_profissional.png"
        plt.tight_layout()
        plt.savefig(output_path, dpi=300, bbox_inches='tight')
        plt.close()
        
        logger.info(f"Gráfico de demografia salvo em: {output_path}")
        return str(output_path)
    
    def generate_market_potential_chart(self) -> str:
        """
        Gera gráfico de potencial de mercado.
        
        Returns:
            str: Caminho do arquivo gerado
        """
        fig, ax = plt.subplots(figsize=(12, 8))
        
        # Dados para o gráfico
        potential = self.calculate_market_potential()
        
        categories = ['Crianças\n0-14 anos', 'Famílias\nEngajadas (70%)', 'Faixa Principal\n5-9 anos', 'Mercado\nPotencial']
        values = [1.1, 0.77, 0.35, 0.385]  # Em milhões
        colors = ['#E3F2FD', '#BBDEFB', '#90CAF9', '#1976D2']
        
        bars = ax.bar(categories, values, color=colors, edgecolor='black', linewidth=1)
        
        # Adicionar valores
        labels = ['1,1M', '770K', '350K', 'R$ 385M']
        for bar, label in zip(bars, labels):
            height = bar.get_height()
            ax.text(bar.get_x() + bar.get_width()/2., height + 0.02,
                   label, ha='center', va='bottom', fontweight='bold', fontsize=12)
        
        # Adicionar setas conectoras
        for i in range(len(bars)-1):
            x1 = bars[i].get_x() + bars[i].get_width()
            x2 = bars[i+1].get_x()
            y = max(bars[i].get_height(), bars[i+1].get_height()) / 2
            
            ax.annotate('', xy=(x2-0.05, y), xytext=(x1+0.05, y),
                       arrowprops=dict(arrowstyle='->', lw=2, color='red'))
        
        # Destacar resultado final
        ax.text(0.02, 0.98, 'Metodologia: 70% das famílias × R$ 500/ano',
                transform=ax.transAxes, fontsize=11,
                bbox=dict(boxstyle="round,pad=0.3", facecolor="lightyellow", alpha=0.8),
                verticalalignment='top')
        
        ax.set_title('Mercado Potencial para Brinquedos Pedagógicos\nVoltados ao Autismo no Brasil', 
                    fontsize=16, fontweight='bold', pad=20)
        ax.set_ylabel('Valores (Milhões)', fontsize=12)
        ax.grid(True, alpha=0.3)
        
        # Salvar gráfico
        output_path = self.output_dir / "potencial_mercado_profissional.png"
        plt.tight_layout()
        plt.savefig(output_path, dpi=300, bbox_inches='tight')
        plt.close()
        
        logger.info(f"Gráfico de potencial salvo em: {output_path}")
        return str(output_path)
    
    def generate_comprehensive_report(self) -> Dict[str, any]:
        """
        Gera relatório completo com todos os cálculos.
        
        Returns:
            Dict[str, any]: Relatório completo com métricas e gráficos
        """
        logger.info("Iniciando geração do relatório completo...")
        
        # Calcular todas as métricas
        market_growth = self.calculate_market_growth()
        autism_demographics = self.calculate_autism_demographics()
        market_potential = self.calculate_market_potential()
        regional_distribution = self.calculate_regional_distribution()
        
        # Gerar gráficos
        growth_chart = self.generate_market_growth_chart()
        demographics_chart = self.generate_autism_demographics_chart()
        potential_chart = self.generate_market_potential_chart()
        
        # Compilar relatório
        report = {
            "metadata": {
                "generated_at": pd.Timestamp.now().isoformat(),
                "version": "1.0.0",
                "author": "FabLab UFPB"
            },
            "market_analysis": market_growth,
            "autism_demographics": autism_demographics,
            "market_potential": market_potential,
            "regional_distribution": regional_distribution,
            "charts": {
                "market_growth": growth_chart,
                "autism_demographics": demographics_chart,
                "market_potential": potential_chart
            },
            "key_insights": {
                "total_market_size": f"R$ {market_growth['current_revenue']:.1f} bilhões",
                "growth_rate": f"{market_growth['total_growth_percent']:.0f}% em 4 anos",
                "target_population": f"{autism_demographics['target_population']:,} crianças",
                "market_opportunity": f"R$ {market_potential['market_potential_millions']:.0f} milhões anuais"
            }
        }
        
        logger.info("Relatório completo gerado com sucesso!")
        return report

def main():
    """Função principal para executar a análise."""
    print("🔍 Iniciando Análise de Mercado - FabLab UFPB + FUNAD")
    print("=" * 60)
    
    # Criar analisador
    analyzer = MarketAnalyzer()
    
    # Gerar relatório completo
    report = analyzer.generate_comprehensive_report()
    
    # Exibir insights principais
    print("\n📊 INSIGHTS PRINCIPAIS:")
    print("-" * 30)
    for key, value in report["key_insights"].items():
        print(f"• {key.replace('_', ' ').title()}: {value}")
    
    print(f"\n📈 Gráficos gerados em: {analyzer.output_dir}")
    print("✅ Análise concluída com sucesso!")
    
    return report

if __name__ == "__main__":
    main()

