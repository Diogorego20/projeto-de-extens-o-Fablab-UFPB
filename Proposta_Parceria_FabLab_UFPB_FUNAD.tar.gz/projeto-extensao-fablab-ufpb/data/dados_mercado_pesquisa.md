# Dados de Pesquisa - Mercado de Brinquedos Pedagógicos para Autismo no Brasil

## Mercado de Brinquedos no Brasil (2024)

### Dados Gerais da Indústria
- **Faturamento 2024**: R$ 10,2 bilhões (crescimento de 8,5% em relação a 2023)
- **Produção nacional**: R$ 5,77 bilhões (mais da metade do faturamento total)
- **Importações**: US$ 334,4 milhões (75,14% vindos da China)
- **Empregos gerados**: 44.092 pessoas
- **Novos produtos lançados em 2024**: 1.450 brinquedos
- **Projeção para 2025**: 1.689 novos produtos

### Canais de Venda
- **Internet**: 28% (principal canal)
- **Atacadistas**: 27%
- **Lojas especializadas**: 27%

### Demografia Infantil
- **Crianças de 0-14 anos em 2024**: 43,75 milhões
- **Projeção para 2034**: 41,25 milhões
- **Média de brinquedos por criança**: 11 unidades

## Dados sobre Autismo no Brasil (Censo 2022)

### Números Gerais
- **Total de pessoas com diagnóstico de TEA**: 2,4 milhões (1,2% da população)
- **Homens**: 1,4 milhões (1,5% da população masculina)
- **Mulheres**: 1,0 milhão (0,9% da população feminina)

### Faixa Etária com Maior Prevalência
- **0-4 anos**: 2,1% da população nesta faixa
- **5-9 anos**: 2,6% da população nesta faixa (maior prevalência)
- **10-14 anos**: 1,9% da população nesta faixa
- **15-19 anos**: 1,3% da população nesta faixa

### Crianças e Adolescentes com Autismo
- **Total de 0-14 anos com autismo**: 1,1 milhão de pessoas
- **Meninos de 5-9 anos**: 3,8% (264,6 mil indivíduos)
- **Meninas de 5-9 anos**: 1,3% (86,3 mil pessoas)

### Educação
- **Estudantes com autismo (6+ anos)**: 760,8 mil
- **Taxa de escolarização**: 36,9% (superior à população geral: 24,3%)
- **Concentração no ensino fundamental**: 66,8% dos estudantes com autismo

### Distribuição Regional
- **Sudeste**: 1+ milhão de pessoas
- **Nordeste**: 633 mil pessoas
- **Sul**: 348,4 mil pessoas
- **Norte**: 202 mil pessoas
- **Centro-Oeste**: 180 mil pessoas

## Oportunidades de Mercado

### Público-Alvo Potencial
- **Crianças de 0-14 anos com autismo**: 1,1 milhão
- **Faixa de maior concentração**: 5-9 anos (350,9 mil crianças)
- **Alta taxa de escolarização**: indica famílias engajadas em desenvolvimento

### Mercado Potencial
- Considerando média de 11 brinquedos por criança
- Mercado específico para autismo ainda em desenvolvimento
- Crescimento da consciência sobre necessidades especiais
- Aumento de diagnósticos e busca por produtos especializados



## Informações sobre FabLab UFPB

### Características do Laboratório
- **Localização**: Centro de Vivências da UFPB, Campus I, João Pessoa-PB
- **Vinculação**: Centro de Energias Alternativas e Renováveis (CEAR)
- **Natureza**: Laboratório multidisciplinar e multiusuário de prototipagem
- **Filosofia**: Autossustentável financeiramente, cultura maker "Faça você mesmo"

### Missão e Objetivos
- Pesquisas de caráter técnico e científico
- Prestação de serviços à UFPB e comunidade externa
- Promoção da cultura maker e inovação
- Atendimento à universidade e comunidades externas

### Projetos Conhecidos
- **Projeto "Cultura Maker"** (parceria com Energisa Paraíba)
- Difusão do conhecimento sobre energia
- Usina Escola Solar
- Espaço Ecocycle
- Participação em eventos de robótica e tecnologia

### Capacidades Técnicas
- Fabricação digital
- Prototipagem
- Impressão 3D
- Corte a laser
- Desenvolvimento de produtos

## Informações sobre FUNAD

### Identificação
- **Nome**: Fundação Centro Integrado de Apoio à Pessoa com Deficiência
- **Natureza**: Fundação estadual da Paraíba
- **Foco**: Atendimento a pessoas com deficiência

### Serviços Oferecidos
- **Carteira de Passe Livre e Identificação da Pessoa com Autismo**
- Cursos de alfabetização para crianças com deficiência visual
- Credenciamento para fornecimento de órteses, próteses e materiais (cadeiras de rodas, etc.)
- Consultas médicas especializadas
- Cursos sobre Altas Habilidades e Superdotação
- Mercado de trabalho para pessoas com deficiência

### Público-Alvo
- Pessoas com deficiência física
- Pessoas com deficiência visual
- Pessoas com autismo
- Pessoas com altas habilidades/superdotação
- Familiares e cuidadores

### Potencial de Parceria
- Experiência em atendimento a pessoas com autismo
- Rede de famílias e profissionais especializados
- Conhecimento das necessidades específicas do público
- Capacidade de validação e teste de produtos
- Alcance estadual na Paraíba

## Oportunidades de Parceria FabLab UFPB + FUNAD

### Sinergia Potencial
1. **Desenvolvimento de Produtos**: FabLab pode criar protótipos de brinquedos pedagógicos
2. **Validação com Usuários**: FUNAD pode testar produtos com famílias e crianças autistas
3. **Capacitação**: Treinamento de profissionais e famílias no uso dos brinquedos
4. **Pesquisa Aplicada**: Estudos sobre eficácia dos brinquedos no desenvolvimento
5. **Impacto Social**: Ações que beneficiam diretamente a comunidade autista da Paraíba

### Benefícios para FabLab UFPB
- Visibilidade em ações sociais
- Aplicação prática da tecnologia
- Pesquisa com impacto social
- Fortalecimento da marca institucional
- Conexão com comunidade externa

