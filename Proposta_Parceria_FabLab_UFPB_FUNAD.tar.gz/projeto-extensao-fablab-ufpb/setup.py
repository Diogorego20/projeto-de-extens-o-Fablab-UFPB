#!/usr/bin/env python3
"""
Setup script para o projeto de extensão FabLab UFPB + FUNAD
"""

from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

with open("requirements.txt", "r", encoding="utf-8") as fh:
    requirements = [line.strip() for line in fh if line.strip() and not line.startswith("#")]

setup(
    name="fablab-funad-partnership",
    version="1.0.0",
    author="FabLab UFPB",
    author_email="fablab@ufpb.br",
    description="Proposta de Parceria para Desenvolvimento de Brinquedos Pedagógicos para Autismo",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/Diogorego20/projeto-de-extens-o-Fablab-UFPB",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Science/Research",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.11",
        "Topic :: Scientific/Engineering :: Information Analysis",
        "Topic :: Education",
        "Topic :: Scientific/Engineering :: Medical Science Apps.",
    ],
    python_requires=">=3.11",
    install_requires=requirements,
    extras_require={
        "dev": [
            "pytest>=7.3.0",
            "black>=23.3.0",
            "flake8>=6.0.0",
            "mypy>=1.3.0",
        ],
        "docs": [
            "sphinx>=6.2.0",
            "sphinx-rtd-theme>=1.2.0",
        ],
    },
    entry_points={
        "console_scripts": [
            "market-analysis=src.market_analysis:main",
        ],
    },
    project_urls={
        "Bug Reports": "https://github.com/Diogorego20/projeto-de-extens-o-Fablab-UFPB/issues",
        "Source": "https://github.com/Diogorego20/projeto-de-extens-o-Fablab-UFPB",
        "Documentation": "https://github.com/Diogorego20/projeto-de-extens-o-Fablab-UFPB/blob/main/README.md",
    },
)

